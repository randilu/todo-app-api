const mockTodos = [
  {
    id: '1',
    title: 'Make the cake',
    description: "First you'll have to choose a recipe. You can keep it simple or you can choose a slightly showier recipe..",
    status: 'completed',
  },
  {
    id: '2',
    title: 'Bake the cake',
    description: 'Put the cake in the oven and wait for it to bake',
    status: 'completed',
  },
  {
    id: '3',
    title: 'Eat the cake',
    description: 'Have fun eating the cake',
    status: 'completed',
  },
];

module.exports = {
  mockTodos,
};
